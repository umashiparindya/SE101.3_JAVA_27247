package com.mycompany.assignment07;
public class Monster extends Item
{
    private int loc;
    private String descrip;
    
    public Monster(int loc,String descrip)
    {
        super(loc,descrip);
        
    }
    
}
