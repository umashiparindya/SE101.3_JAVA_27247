/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exceptionlab03;

/**
 *
 * @author Intel
 */
public class ExceptionLab03 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
