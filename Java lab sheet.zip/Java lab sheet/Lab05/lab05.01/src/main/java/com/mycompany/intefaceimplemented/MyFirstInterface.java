package com.mycompany.intefaceimplemented;
public interface MyFirstInterface 
{
    int x = 10;
    void display();
}
