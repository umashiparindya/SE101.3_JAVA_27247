package com.mycompany.intefaceimplemented;
public class IntefaceImplemented implements MyFirstInterface 
{
    public void display() 
    {
        System.out.println("Value of x: " + x);
    }
}
