
package Hello;

public class java 
{
    public static void main(String[] args)
    {
        int a=0;
        while(a<5)
        {
            System.out.println("Executing loop "+a);
            a++;
        }   
    }
}
