package com.mycompany.project02;
public class Project02 
{

    public static void main(String[] args)
    {
        System.out.println("My name is KSK Jagoda");
        System.out.println("My degree programme is MIS");
    }
}
