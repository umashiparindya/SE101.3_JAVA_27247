/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.breakcontinue;

/**
 *
 * @author Intel
 */
public class BreakContinue {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
