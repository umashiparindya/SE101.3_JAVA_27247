/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical01qone;

/**
 *
 * @author Intel
 */
public class Practical01qone {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
