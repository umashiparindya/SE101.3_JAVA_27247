package com.mycompany.absractquestion;
abstract class Container 
{
    abstract double volume();
}
