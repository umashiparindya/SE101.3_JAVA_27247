package com.mycompany.absractquestion;
public class AbsractQuestion {

    public static void main(String[] args)
    {
        CylindricalContainer c = new CylindricalContainer(8.10,10.50);
        System.out.println(" Volume of the cylinder is "+c.volume());
    }
}
