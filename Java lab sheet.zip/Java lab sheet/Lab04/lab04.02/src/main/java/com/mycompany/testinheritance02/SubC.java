package com.mycompany.testinheritance02;
public class SubC extends SuperB
{
    void triple () {x=x+3;} // override existing method
    void quadruple () {x=x*4;} // new method    
}
