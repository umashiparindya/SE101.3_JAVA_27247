package com.mycompany.dog;

public class Reptile extends Animal {
    
}
