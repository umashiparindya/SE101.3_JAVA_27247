package com.mycompany.dog;
public class Dog {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
