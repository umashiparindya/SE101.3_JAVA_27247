package com.mycompany.dog;

public class Mammal extends Animal
{
    
}
