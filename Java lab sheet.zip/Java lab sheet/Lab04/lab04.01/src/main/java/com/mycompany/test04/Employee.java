package com.mycompany.test04;
public class Employee 
{
    private int empId;
    private String empName;
    private String empDesig;
   
    public int getEmpid()
    {
        return empId;
    }
    public void setEmpid(int empId)
    {
        this.empId=empId;
    }
    public String getEmpN()
    {
        return empName;
    }
    public void setEmpN(String empName)
    {
        this.empName=empName;
    }
    public String getEmpDes()
    {
        return empDesig;
    }
    public void setEmpDes(String empDesig)
    {
        this.empDesig=empDesig;
    }
}
