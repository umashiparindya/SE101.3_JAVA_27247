package com.mycompany.bankaccountmain;
public class BankAccountMain {

    public static void main(String[] args)
    {
        
    }
}
