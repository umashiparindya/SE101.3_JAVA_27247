package com.mycompany.shapemain;
public abstract class ShapeMain {

    public static void main(String[] args)
    {
        
    }
}
